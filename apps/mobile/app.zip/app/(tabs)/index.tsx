import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { useAppStore } from "../../src/store";
import { colors, spacing, borderRadius, shadows } from "../../src/styles/theme";

export default function HomeDashboard() {
  const router = useRouter();
  const { prefs } = useAppStore();

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Goal card */}
      <Text style={styles.label}>Your Goal</Text>
      <View style={styles.goalCard}>
        <View style={styles.goalContent}>
          <Text style={styles.goalText}>
            {prefs.goal ?? "Set your goal"}
          </Text>
          <Text style={styles.goalSubtext}>Personalized planning</Text>
        </View>
        <TouchableOpacity
          style={styles.profileButton}
          onPress={() => router.push("/profile")}
        >
          <Text style={styles.emoji}>👤</Text>
        </TouchableOpacity>
      </View>

      {/* Tiles */}
      <View style={styles.tilesContainer}>
        <DashboardTile
          icon="🛒"
          title="Plan Groceries"
          subtitle="Plan by meal types"
          onPress={() => router.push("/(tabs)/planner")}
        />
        <DashboardTile
          icon="✨"
          title="AI Recs"
          subtitle="Smart grocery suggestions"
          onPress={() => router.push("/planner-recommendations")}
        />
        <DashboardTile
          icon="📍"
          title="Find Stores"
          subtitle="Nearby supermarkets"
          onPress={() => router.push("/(tabs)/stores")}
        />
        <DashboardTile
          icon="📝"
          title="My Lists"
          subtitle="Active & saved lists"
          onPress={() => router.push("/(tabs)/lists")}
        />
      </View>

      {/* Weekly deals */}
      <Text style={styles.sectionTitle}>Weekly Deals</Text>

      <View style={[styles.dealCard, styles.greenDeal]}>
        <Text style={styles.dealTitle}>20% off vegetables</Text>
        <Text style={styles.dealStore}>FairPrice</Text>
      </View>

      <View style={[styles.dealCard, styles.blueDeal]}>
        <Text style={styles.dealTitle}>Buy 2 Get 1 Free Yogurt</Text>
        <Text style={styles.dealStore}>Cold Storage</Text>
      </View>

      <View style={styles.spacer} />
    </ScrollView>
  );
}

type TileProps = {
  icon: string;
  title: string;
  subtitle: string;
  onPress: () => void;
};

function DashboardTile({ icon, title, subtitle, onPress }: TileProps) {
  return (
    <TouchableOpacity style={styles.tile} activeOpacity={0.8} onPress={onPress}>
      <View style={styles.tileContent}>
        <Text style={styles.tileIcon}>{icon}</Text>
        <Text style={styles.tileTitle}>{title}</Text>
        <Text style={styles.tileSubtitle}>{subtitle}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  content: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
  },
  label: {
    fontSize: 12,
    color: colors.gray[400],
    marginBottom: 4,
  },
  goalCard: {
    backgroundColor: colors.white,
    borderRadius: borderRadius['2xl'],
    padding: spacing.lg,
    marginBottom: spacing['2xl'],
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...shadows.sm,
  },
  goalContent: {
    flex: 1,
    marginRight: 12,
  },
  goalText: {
    color: colors.brand.DEFAULT,
    fontSize: 14,
    fontWeight: '600',
  },
  goalSubtext: {
    color: colors.gray[500],
    fontSize: 12,
    marginTop: 2,
  },
  profileButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.gray[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  emoji: {
    fontSize: 18,
  },
  tilesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -4,
    marginBottom: spacing['3xl'],
  },
  tile: {
    width: '50%',
    paddingHorizontal: 4,
    marginBottom: 12,
  },
  tileContent: {
    backgroundColor: colors.white,
    borderRadius: borderRadius['2xl'],
    padding: spacing.lg,
    height: '100%',
    ...shadows.sm,
  },
  tileIcon: {
    fontSize: 28,
    marginBottom: 4,
  },
  tileTitle: {
    fontWeight: '600',
    fontSize: 14,
    marginBottom: 2,
  },
  tileSubtitle: {
    color: colors.gray[500],
    fontSize: 12,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  dealCard: {
    borderRadius: borderRadius['2xl'],
    padding: spacing.lg,
    marginBottom: 12,
  },
  greenDeal: {
    backgroundColor: colors.green[50],
  },
  blueDeal: {
    backgroundColor: colors.blue[50],
  },
  dealTitle: {
    fontSize: 14,
    fontWeight: '500',
  },
  dealStore: {
    fontSize: 12,
    color: colors.gray[500],
    marginTop: 2,
  },
  spacer: {
    height: 24,
  },
});