// lib/screens/vision_screen.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'dart:io';

import '../config/env_config.dart';
import '../theme/app_colors.dart';


class VisionScreen extends StatefulWidget {
  final String userId;
  const VisionScreen({super.key, required this.userId});
  
  @override
  State<VisionScreen> createState() => _VisionScreenState();
}

class _VisionScreenState extends State<VisionScreen> {
  final ImagePicker _picker = ImagePicker();
  List<dynamic> _detectedItems = [];
  bool _isAnalyzing = false;
  
  Future<void> _captureAndAnalyze() async {
    // Pick image
    final XFile? image = await _picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
    );
    
    if (image == null) return;
    
    setState(() => _isAnalyzing = true);
    
    try {
      // Read image as bytes
      final bytes = await File(image.path).readAsBytes();
      final base64Image = base64Encode(bytes);
      
      // Send to backend
      final response = await http.post(
        Uri.parse('${EnvConfig.backendUrl}/api/vision/analyze'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'userId': widget.userId,
          'imageBase64': base64Image,
          'imageType': 'image/jpeg',
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _detectedItems = data['detectedItems'];
          _isAnalyzing = false;
        });
        
        // Show results dialog
        _showDetectedItems();
      }
    } catch (e) {
      print('Error analyzing image: $e');
      setState(() => _isAnalyzing = false);
    }
  }
  
  void _showDetectedItems() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text('Detected Items', style: Theme.of(context).textTheme.headlineSmall),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _detectedItems.length,
                itemBuilder: (context, index) {
                  final item = _detectedItems[index];
                  return CheckboxListTile(
                    title: Text(item['item']),
                    subtitle: Text('${item['quantity']} ${item['unit']}'),
                    value: true,
                    onChanged: (val) {},
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () => _addToInventory(),
              child: Text('Add to Inventory'),
            ),
          ],
        ),
      ),
    );
  }
  
  Future<void> _addToInventory() async {
    final response = await http.post(
      Uri.parse('${EnvConfig.backendUrl}/api/inventory/add-from-vision'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'userId': widget.userId,
        'items': _detectedItems,
      }),
    );
    
    if (response.statusCode == 200) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Added to inventory!')),
      );
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Scan Inventory')),
      body: Center(
        child: _isAnalyzing
          ? CircularProgressIndicator()
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.camera_alt, size: 100, color: AppColors.primary),
                SizedBox(height: 24),
                Text('Scan your fridge or pantry'),
                SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: _captureAndAnalyze,
                  icon: Icon(Icons.camera),
                  label: Text('Take Photo'),
                ),
              ],
            ),
      ),
    );
  }
}