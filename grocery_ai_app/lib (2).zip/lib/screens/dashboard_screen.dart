import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../config/env_config.dart';
import '../theme/app_colors.dart';

class DashboardScreen extends StatefulWidget {
  final String userId;
  
  const DashboardScreen({super.key, required this.userId});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool _isLoading = true;
  Map<String, dynamic>? _todayData;
  List<dynamic>? _weekData;
  Map<String, dynamic>? _goals;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    
    try {
      // Load today's data
      final todayResponse = await http.get(
        Uri.parse('${EnvConfig.backendUrl}/api/dashboard/${widget.userId}/today'),
      );
      
      // Load week's data
      final weekResponse = await http.get(
        Uri.parse('${EnvConfig.backendUrl}/api/dashboard/${widget.userId}/week'),
      );
      
      if (todayResponse.statusCode == 200 && weekResponse.statusCode == 200) {
        final todayJson = jsonDecode(todayResponse.body);
        final weekJson = jsonDecode(weekResponse.body);
        
        setState(() {
          _todayData = todayJson['today'];
          _goals = todayJson['goals'];
          _weekData = weekJson['weekSummary'];
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading dashboard: $e');
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Macro Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadDashboardData,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadDashboardData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Today's Summary Card
                    _buildTodaySummaryCard(),
                    const SizedBox(height: 20),
                    
                    // Macro Breakdown
                    Text(
                      "Today's Macros",
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 16),
                    _buildMacroBreakdown(),
                    const SizedBox(height: 24),
                    
                    // Weekly Progress
                    Text(
                      '7-Day Progress',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 16),
                    _buildWeeklyChart(),
                    const SizedBox(height: 24),
                    
                    // Quick Actions
                    _buildQuickActions(),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildTodaySummaryCard() {
    final calories = (_todayData?['total_calories'] ?? 0).toDouble();
    final calorieGoal = (_goals?['calories'] ?? 2000).toDouble();
    final percentage = (calories / calorieGoal * 100).toInt();
    final mealsLogged = _todayData?['meals_logged'] ?? 0;

    return Card(
      elevation: 4,
      child: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Today\'s Calories',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${calories.toInt()} / ${calorieGoal.toInt()}',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$percentage% of goal',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.restaurant, color: Colors.white, size: 32),
                      const SizedBox(height: 4),
                      Text(
                        '$mealsLogged',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Text(
                        'meals',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: calories / calorieGoal,
                backgroundColor: Colors.white24,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                minHeight: 8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMacroBreakdown() {
    final protein = (_todayData?['total_protein'] ?? 0).toDouble();
    final carbs = (_todayData?['total_carbs'] ?? 0).toDouble();
    final fat = (_todayData?['total_fat'] ?? 0).toDouble();

    final proteinGoal = (_goals?['protein'] ?? 150).toDouble();
    final carbsGoal = (_goals?['carbs'] ?? 200).toDouble();
    final fatGoal = (_goals?['fat'] ?? 65).toDouble();

    return Column(
      children: [
        _buildMacroBar(
          'Protein',
          protein,
          proteinGoal,
          'g',
          AppColors.primary,
          Icons.fitness_center,
        ),
        const SizedBox(height: 12),
        _buildMacroBar(
          'Carbs',
          carbs,
          carbsGoal,
          'g',
          AppColors.secondary,
          Icons.grain,
        ),
        const SizedBox(height: 12),
        _buildMacroBar(
          'Fat',
          fat,
          fatGoal,
          'g',
          AppColors.info,
          Icons.local_fire_department,
        ),
      ],
    );
  }

  Widget _buildMacroBar(
    String label,
    double current,
    double goal,
    String unit,
    Color color,
    IconData icon,
  ) {
    final percentage = (current / goal).clamp(0.0, 1.0);
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${current.toInt()}$unit / ${goal.toInt()}$unit',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '${(percentage * 100).toInt()}%',
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: percentage,
                backgroundColor: color.withOpacity(0.1),
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeeklyChart() {
    if (_weekData == null || _weekData!.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Center(
            child: Text('No data for the past week'),
          ),
        ),
      );
    }

    // Calculate max value for scaling
    double maxCalories = 0;
    for (var day in _weekData!) {
      final cals = (day['total_calories'] ?? 0).toDouble();
      if (cals > maxCalories) maxCalories = cals;
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Legend
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildLegendItem('Calories', AppColors.primary),
                _buildLegendItem('Protein', AppColors.secondary),
                _buildLegendItem('Carbs', AppColors.info),
              ],
            ),
            const SizedBox(height: 20),
            // Bar chart
            SizedBox(
              height: 200,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: _weekData!.take(7).map((day) {
                  final calories = (day['total_calories'] ?? 0).toDouble();
                  final height = maxCalories > 0 
                      ? (calories / maxCalories * 150).clamp(10.0, 150.0) 
                      : 10.0;
                  
                  final date = DateTime.parse(day['date']);
                  final dayName = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][date.weekday - 1];
                  
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            calories.toInt().toString(),
                            style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            width: double.infinity,
                            height: height,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [
                                  AppColors.primary,
                                  AppColors.primary.withOpacity(0.7),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            dayName,
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: const TextStyle(fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildActionButton(
                'Log Food',
                Icons.add_circle,
                AppColors.primary,
                () {
                  // Navigate to food logging
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionButton(
                'Scan Item',
                Icons.camera_alt,
                AppColors.secondary,
                () {
                  // Navigate to camera
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton(
    String label,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, color: color, size: 32),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}